// Light Toggle
const lightStatus = document.getElementById("light-status");
const lightToggleBtn = document.getElementById("toggle-light");
const brightnessSlider = document.getElementById("light-brightness");

let isLightOn = JSON.parse(localStorage.getItem("isLightOn")) ?? true;
lightStatus.textContent = isLightOn ? "ON" : "OFF";
lightStatus.className = `status ${isLightOn ? "on" : "off"}`;

lightToggleBtn.addEventListener("click", () => {
  isLightOn = !isLightOn;
  lightStatus.textContent = isLightOn ? "ON" : "OFF";
  lightStatus.className = `status ${isLightOn ? "on" : "off"}`;
  localStorage.setItem("isLightOn", isLightOn);
});

brightnessSlider.addEventListener("input", (e) => {
  const value = e.target.value;
  if (isLightOn) {
    lightStatus.textContent = `ON (${value}%)`;
  }
});

// Security Toggle
const securityStatus = document.getElementById("security-status");
const securityBtn = document.getElementById("toggle-security");

let isArmed = JSON.parse(localStorage.getItem("isArmed")) ?? true;
securityStatus.textContent = isArmed ? "ARMED" : "DISARMED";
securityStatus.className = `status ${isArmed ? "armed" : "disarmed"}`;
securityBtn.textContent = isArmed ? "Disarm" : "Arm";

securityBtn.addEventListener("click", () => {
  isArmed = !isArmed;
  securityStatus.textContent = isArmed ? "ARMED" : "DISARMED";
  securityStatus.className = `status ${isArmed ? "armed" : "disarmed"}`;
  securityBtn.textContent = isArmed ? "Disarm" : "Arm";
  localStorage.setItem("isArmed", isArmed);
});

// Thermostat
const currentTemp = document.getElementById("current-temp");
const targetTempInput = document.getElementById("target-temp");
const setTempBtn = document.getElementById("set-temp");
let simulatedTemp = 22;

setTempBtn.addEventListener("click", () => {
  const target = parseInt(targetTempInput.value);
  const interval = setInterval(() => {
    if (simulatedTemp < target) simulatedTemp += 1;
    else if (simulatedTemp > target) simulatedTemp -= 1;
    currentTemp.textContent = `${simulatedTemp}°C`;
    if (simulatedTemp === target) clearInterval(interval);
  }, 1000);
});

// Clock
const clockEl = document.getElementById("clock");
function updateClock() {
  const now = new Date();
  clockEl.textContent = now.toLocaleTimeString();
}
setInterval(updateClock, 1000);
updateClock();

// Scenes
const sceneButtons = document.querySelectorAll(".scene-btn");
sceneButtons.forEach(button => {
  button.addEventListener("click", () => {
    const scene = button.dataset.scene;
    switch (scene) {
      case "movie":
        isLightOn = false;
        lightStatus.textContent = "OFF (Movie Mode)";
        lightStatus.className = "status off";
        brightnessSlider.value = 30;
        simulatedTemp = 21;
        currentTemp.textContent = "21°C";
        break;
      case "sleep":
        isLightOn = false;
        lightStatus.textContent = "OFF (Sleep Mode)";
        lightStatus.className = "status off";
        simulatedTemp = 19;
        currentTemp.textContent = "19°C";
        isArmed = true;
        securityStatus.textContent = "ARMED";
        securityStatus.className = "status armed";
        securityBtn.textContent = "Disarm";
        break;
      case "away":
        isLightOn = false;
        lightStatus.textContent = "OFF (Away)";
        lightStatus.className = "status off";
        simulatedTemp = 18;
        currentTemp.textContent = "18°C";
        isArmed = true;
        securityStatus.textContent = "ARMED";
        securityStatus.className = "status armed";
        securityBtn.textContent = "Disarm";
        break;
    }
    localStorage.setItem("isLightOn", isLightOn);
    localStorage.setItem("isArmed", isArmed);
  });
});

// Chart.js - Sample Energy Chart
const ctx = document.getElementById('energyChart')?.getContext('2d');
if (ctx) {
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
      datasets: [{
        label: 'kWh Used',
        data: [3.5, 4.2, 3.8, 4.0, 4.6, 5.0, 4.1],
        backgroundColor: '#0077cc'
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            color: '#333'
          }
        },
        x: {
          ticks: {
            color: '#333'
          }
        }
      }
    }
  });
}

// 🧠 Placeholder: Connect to Smart Home API (e.g., Home Assistant or custom backend)
async function fetchDeviceData() {
  try {
    // const response = await fetch('https://api.smart-home.local/devices');
    // const data = await response.json();
    // console.log("Fetched device data:", data);
  } catch (error) {
    console.error("API fetch failed:", error);
  }
}

fetchDeviceData(); // Call once on load

// 🌙 Dark Mode Toggle
const themeToggle = document.getElementById("theme-toggle");
themeToggle?.addEventListener("click", () => {
  document.body.classList.toggle("dark");
  localStorage.setItem("theme", document.body.classList.contains("dark") ? "dark" : "light");
});

// On load, apply saved theme
if (localStorage.getItem("theme") === "dark") {
  document.body.classList.add("dark");
}
